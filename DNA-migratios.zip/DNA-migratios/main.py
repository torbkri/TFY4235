
from Params import Params
# from task3 import plot_potential_and_force
# from task4 import gaussian_random, test_gaussian
from task5 import plot_trajectory
from task6 import run_simulation

params = Params(alpha=0.2, DU=26E-2, KBT=26E-3, tau=100, dt=0.1)

def main() -> None:
    
    run_data = run_simulation(x0_hat=0.0, t_end_hat=params.tau, params=params, flashing_on=True)
    # plot_potential_and_force(alpha=params.alpha, tau_hat=params.tau, t_hat=0.9*params.tau)
    # test_gaussian(gaussian_random)
    plot_trajectory(run_data=run_data)


main()