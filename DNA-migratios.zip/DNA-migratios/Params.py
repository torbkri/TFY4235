from dataclasses import dataclass

@dataclass
class Params:
    alpha: float
    DU: float
    KBT:float
    tau: float
    dt: float
